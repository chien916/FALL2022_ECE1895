#include <QObject>
#ifndef MYDEBUGWINDOWCONTROLLER_H
#define MYDEBUGWINDOWCONTROLLER_H
class MyDebugWindowController:public QObject{
	Q_OBJECT
public:

};

#endif // MYDEBUGWINDOWCONTROLLER_H
